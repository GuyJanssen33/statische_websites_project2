# Voorstelling

een project waarbij ik een website moet ontewerpen.  Dit moet een Portfolio worden die ik kan gebruiken als 'reclamebord' voor mijn toekomstig beroep.
