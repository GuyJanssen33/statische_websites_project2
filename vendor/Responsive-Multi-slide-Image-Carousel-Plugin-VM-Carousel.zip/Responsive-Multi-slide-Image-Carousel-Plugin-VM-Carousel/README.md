# VM Carousel

## Coming soon...

### License
  
VM Carousel is licensed under the [MIT license](http://opensource.org/licenses/MIT).

Copyright (c) 2016 Vedmant